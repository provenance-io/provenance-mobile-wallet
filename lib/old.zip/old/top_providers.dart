import 'package:dio/dio.dart';
import 'package:flutter_tech_wallet/services/deep_link_service.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:uni_links/uni_links.dart';

export 'package:collection/collection.dart';
export 'package:flutter_tech_wallet/util/extensions.dart';
export 'package:hooks_riverpod/hooks_riverpod.dart';

// This file contains global providers

final uriLinkStreamProvider = StreamProvider<Uri?>((ref) {
  return uriLinkStream;
});

final deepLinkServiceProvider = Provider((_) => DeepLinkService());

final isProdProvider = StateProvider((_) => false);

final _dioProvider = Provider<Dio>((ref) {
  final isProd = ref.watch(isProdProvider).state;
  final options = BaseOptions(
    baseUrl: isProd ? 'https://www.figure.com/' : 'https://test.figure.com/',
    receiveTimeout: 60000,
    connectTimeout: 60000,
  );
  return Dio(options);
});

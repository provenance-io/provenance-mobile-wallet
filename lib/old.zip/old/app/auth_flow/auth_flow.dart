import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:flutter_tech_wallet/app/home_page.dart';
import 'package:flutter_tech_wallet/common/widgets/loading_overlay.dart';
import 'package:flutter_tech_wallet/flow/flow_builder.dart';
import 'package:flutter_tech_wallet/top_providers.dart';
import 'package:flutter_tech_wallet/util/extensions.dart';

final authModel = StateNotifierProvider((ref) => AuthModel(false));

final isLoadingProvider = Provider.autoDispose<bool>((ref) {
  return ref.watch(authModel).when<bool>(
        data: (_) => false,
        loading: () => true,
        error: (_, __) => false,
      );
});

class AuthModel extends StateNotifier<bool> {
  AuthModel(bool state) : super(state);

  void createWallet() => state = true;
  void authExistingWallet() => state = true;
  void logOut() => state = false;
}

class AuthFlow extends HookWidget {
  const AuthFlow({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final state = useProvider(authModel);
    final isLoading = useProvider(isLoadingProvider);

    return LoadingOverlay(
        isLoading: isLoading,
        child: FlowBuilder<bool>(
          state: state,
          onGeneratePages: _pages,
        ));
  }

  List<Page> _pages(bool authenticated) {
    return authenticated
        ? [const HomePage().page()]
        : [const LoggedOut().page()];
  }
}

class LoggedOut extends HookWidget {
  const LoggedOut({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('Logged Out'),
            ElevatedButton(
                onPressed: () {
                  context.read(authModel.notifier).authExistingWallet();
                },
                child: const Text('Log In'))
          ],
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:flutter_tech_wallet/app/options_menu_vm.dart';
import 'package:flutter_tech_wallet/common/widgets/loading_overlay.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

enum _options {
  requestAccountInfo,
}

class OptionsMenu extends HookWidget {
  const OptionsMenu({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final isLoading = useProvider(isLoadingProvider);

    return LoadingOverlay(
      isLoading: isLoading,
      child: Scaffold(
        appBar: AppBar(),
        body: ProviderListener<AsyncValue<String?>>(
            provider: accountInfoProvider,
            onChange: (context, value) {
              if (value is AsyncError) {
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return AlertDialog(
                      content: Text((value as AsyncError).error.toString()),
                    );
                  },
                );
              }
            },
            child: _itemList(context)),
      ),
    );
  }

  Widget _itemList(BuildContext context) {
    const options = _options.values;

    final accountInfo = useProvider(accountInfoProvider);

    return ListView.separated(
        itemBuilder: (context, index) {
          final item = options[index];
          return ListTile(
            title: Text(item.name),
            subtitle: item != _options.requestAccountInfo
                ? null
                : accountInfo.data?.value == null
                    ? null
                    : Text(accountInfo.data!.value!),
            trailing: const Icon(Icons.launch),
            onTap: () {
              context
                  .read(accountInfoProvider.notifier)
                  .requestFigurePayAccountInfo();
            },
          );
        },
        separatorBuilder: (_, __) => const Divider(),
        itemCount: options.length);
  }
}

extension on _options {
  String get name {
    switch (this) {
      case _options.requestAccountInfo:
        return 'Request FigurePay Account Info';
    }
  }
}

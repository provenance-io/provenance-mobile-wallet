import 'dart:async';

import 'package:flutter_tech_wallet/services/deep_link_service.dart';

import '../top_providers.dart';

final isLoadingProvider = Provider.autoDispose<bool>((ref) {
  return ref.watch(accountInfoProvider).when<bool>(
        data: (_) => false,
        loading: () => true,
        error: (_, __) => false,
      );
});

final accountInfoProvider =
    StateNotifierProvider.autoDispose<AccountInfoNotifier, AsyncValue<String?>>(
        (ref) => AccountInfoNotifier(ref.watch(deepLinkServiceProvider)));

class AccountInfoNotifier extends StateNotifier<AsyncValue<String?>> {
  AccountInfoNotifier(this._deepLinkService) : super(const AsyncData(null));

  final DeepLinkService _deepLinkService;
  StreamSubscription? _streamSubscription;
  Timer? _timer;

  @override
  void dispose() {
    _streamSubscription?.cancel();
    _timer?.cancel();
    super.dispose();
  }

  Future<void> requestFigurePayAccountInfo() async {
    state = const AsyncLoading();
    await _deepLinkService.requestAccountId();

    // start listening for response
    _streamSubscription = _deepLinkService.linkStream.listen(
      (uri) {
        print(uri.toString());
        if (uri == null) return;

        if (uri.path.startsWith('getUser')) {
          _timer?.cancel();
          final username = uri.queryParameters['username'];
          final accountId = uri.queryParameters['account_id'];

          if (username != null && accountId != null) {
            state = AsyncData(username);
          } else {
            state = AsyncError('Failed to get Username/Account ID');
          }
        }

        // if success, cancel timer
      },
      onError: (error) => state = AsyncError(error),
    );

    _timer = Timer(const Duration(seconds: 20), () {
      if (mounted) {
        _streamSubscription?.cancel();
        state = AsyncError(TimeoutException('Failed to get Account Info'));
      }
    });
  }
}

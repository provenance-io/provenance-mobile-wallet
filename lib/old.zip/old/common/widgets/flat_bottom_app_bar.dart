import 'package:flutter/material.dart';

class FlatBottomAppBar extends StatelessWidget {
  const FlatBottomAppBar({
    Key? key,
    required this.child,
    this.color = Colors.transparent,
  }) : super(key: key);

  final Widget child;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return BottomAppBar(
      color: color,
      elevation: 0,
      child: SafeArea(
        minimum: const EdgeInsets.all(16.0),
        child: child,
      ),
    );
  }
}

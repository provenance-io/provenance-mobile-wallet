import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

/// {@template flow_controller}
/// A controller which exposes APIs to [update] and [complete]
/// the current flow.
///
/// Using [ChangeNotifier] for updating a generic state that always notifies
/// listeners even if the value of state did not change
/// unlike [ValueNotifier] or [StateNotifier]
/// {@endtemplate}
class FlowController<T> extends ChangeNotifier {
  /// {@macro flow_controller}
  FlowController(T state) : this._(state);
  FlowController._(this._state) : _initialState = _state;
  T _state;
  T _initialState;
  T get state => _state;

  bool _completed = false;

  /// Whether the current flow has been completed.
  bool get completed => _completed;

  /// [update] can be called to update the current flow state.
  ///
  /// When [update] is called, the `builder` method of the corresponding
  /// [FlowBuilder] will be called with the new flow state.
  void update(T state) {
    _state = state;
    notifyListeners();
  }

  /// [complete] can be called to complete the current flow and set completed
  /// state which is useful for cases where controllers stay alive
  /// longer than the builders they control
  ///
  /// If `state` is not provided, it is set to the initial state of when the
  /// controller was created
  ///
  /// When [complete] is called, the flow is popped.
  void complete({T? state}) {
    _completed = true;
    update(state ?? _initialState);
    _completed = false; // reset after notifying
  }
}

/// Signature for function which generates a [List<Page>] given an input of [T]
/// and the current [List<Page>].
typedef OnGeneratePages<T> = List<Page> Function(T);

/// {@template flow_builder}
/// [FlowBuilder] abstracts Navigator 2.0 and exposes a declarative routing API
/// based on a [state].
///
/// Completing a flow results in the flow being popped from
/// the navigation stack with the resulting flow state.
///
/// To be notified of completion, provide implementation for `onComplete`.
///
/// ```dart
/// final controller = FlowController<MyFlowState>(MyInitialState);
///
/// FlowBuilder<MyFlowState>(
///   controller: controller,
///   onGeneratePages: (state) {...},
///   onComplete: (state) {
///     // do something when flow is completed...
///   }
/// )
/// ```
/// {@endtemplate}
class FlowBuilder<T> extends StatefulWidget {
  /// {@macro flow_builder}
  const FlowBuilder({
    Key? key,
    this.state,
    this.controller,
    required this.onGeneratePages,
    this.onComplete,
    this.observers = const <NavigatorObserver>[],
  })  : assert(
          state != null || controller != null,
          'requires either state or controller',
        ),
        assert(
          !(state != null && controller != null),
          'cannot provide controller and state',
        ),
        super(key: key);

  /// The inital state of the flow when the builder is created.
  final T? state;

  /// Builds a [List<Page>] based on the current state.
  final OnGeneratePages<T> onGeneratePages;

  /// Optional [ValueSetter<T>] which is invoked when the
  /// flow has been completed with the final flow state.
  final ValueSetter<T>? onComplete;

  /// Optional [FlowController] which will be used to control flow.
  final FlowController<T>? controller;

  /// A list of [NavigatorObserver] for this [FlowBuilder].
  final List<NavigatorObserver> observers;

  @override
  _FlowBuilderState<T> createState() => _FlowBuilderState<T>();
}

class _FlowBuilderState<T> extends State<FlowBuilder<T>> {
  FlowController<T>? _controller;

  var _pages = <Page>[];
  T get _state => _controller?.state ?? widget.state!;

  @override
  void initState() {
    super.initState();
    _initController(widget.state);
    _pages = widget.onGeneratePages(_state);
  }

  @override
  void didUpdateWidget(FlowBuilder<T> oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.state != widget.state) {
      _removeListeners();
      _initController(widget.state);
      _pages = widget.onGeneratePages(_state);
    } else if (oldWidget.controller != widget.controller) {
      _removeListeners();
      _initController(widget.state);
      _pages = widget.onGeneratePages(_state);
    }
  }

  void _initController(T? state) {
    if (state != null) {
      widget.controller?.update(state);
    }
    widget.controller?.addListener(_listener);
    _controller = widget.controller;
  }

  void _removeListeners() {
    _controller?.removeListener(_listener);
  }

  @override
  void dispose() {
    _removeListeners();
    super.dispose();
  }

  void _listener() {
    if (_controller?.completed ?? false) {
      widget.onComplete?.call(_state);
      if (mounted) return Navigator.of(context).pop(_state);
    }

    setState(() {
      _pages = widget.onGeneratePages(_state);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Navigator(
      pages: _pages,
      observers: widget.observers,
      onPopPage: (route, dynamic result) {
        print('Route:' + route.toString());
        print('Result:' + result.toString());
        return route.didPop(result);
      },
    );
  }
}

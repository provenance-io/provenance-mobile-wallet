import 'package:uni_links/uni_links.dart';
import 'package:url_launcher/url_launcher.dart';

class DeepLinkService {
  static const myScheme = 'figurefoods';
  static final Uri _figurePayUri = Uri(scheme: 'figurepay', host: 'figure.com');

  Stream<Uri?> get linkStream => uriLinkStream;

  bool initialLinkHandled = false;

  Future<Uri?> get initialUri async {
    if (initialLinkHandled) return null;
    initialLinkHandled = true;

    try {
      // Use the uri and warn the user, if it is not correct,
      // but keep in mind it could be `null`.
      final initialUri = await getInitialUri();
      print('initialUri: $initialUri');
      return initialUri;
    } on FormatException catch (e) {
      // Handle exception by warning the user their action did not succeed
      print(e);
      return null;
    }
  }

  Future<bool> launchInvoiceLink({required String invoiceId}) async {
    final callbackUri =
        Uri(scheme: myScheme, pathSegments: ['invoices', invoiceId]);

    final url = _figurePayUri.replace(
        pathSegments: ['figurepay', 'invoices', invoiceId],
        queryParameters: {'callback_uri': callbackUri.toString()}).toString();

    print('Launching: $url');
    print('canLaunch: ${await canLaunch(url)}');
    return launch(url);
  }

  String? getInvoiceIdFromUri(Uri uri) {
    if (uri.scheme == myScheme &&
        uri.pathSegments.length == 2 &&
        uri.pathSegments.first == 'invoices') {
      return uri.pathSegments[1];
    }

    return null;
  }

  Future<bool> requestAccountId() {
    final callbackUri = Uri(scheme: myScheme, pathSegments: ['getUser']);

    final url = _figurePayUri.replace(pathSegments: [
      'figurepay',
      'getUser'
    ], queryParameters: {
      'app_name': 'Figure Foods',
      'callback_uri': callbackUri.toString(),
    }).toString();

    print('Launching: $url');
    return launch(url);
  }
}

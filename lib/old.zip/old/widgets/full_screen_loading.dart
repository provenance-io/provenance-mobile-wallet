// import 'package:figure_pay/util/figure_color.dart';
// import 'package:figure_pay/util/figure_font.dart';
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:percent_indicator/circular_percent_indicator.dart';
//
// class FullScreenLoading extends StatelessWidget {
//   final bool loading;
//   final bool hideButtons;
//   final double size;
//   final String text;
//   final Widget? child;
//   final Color color;
//
//   FullScreenLoading(
//       {this.loading = false,
//       this.hideButtons = false,
//       this.color = Colors.white,
//       this.size = 25.0,
//       this.text = '',
//       @required this.child});
//
//   @override
//   Widget build(BuildContext context) {
//     return GestureDetector(
//       onTap: () => FocusScope.of(context).unfocus(),
//       child: Stack(
//         children: <Widget>[
//           Positioned(
//             left: 0,
//             right: 0,
//             top: 0,
//             bottom: 0,
//             child: child ?? Container(),
//           ),
//           loading && hideButtons
//               ? Positioned(
//                   left: 0,
//                   right: 0,
//                   top: 0,
//                   child: SafeArea(
//                     child: Container(
//                         height: 50.0,
//                         child: Row(children: [
//                           Stack(children: [
//                             Container(
//                               height: 40,
//                               width: 75,
//                               color: color,
//                             ),
//                           ]),
//                           Expanded(
//                             child: Container(),
//                           ),
//                           Stack(children: [
//                             Container(
//                               height: 40,
//                               width: 75,
//                               color: color,
//                             ),
//                           ])
//                         ])),
//                   ))
//               : Container(),
//           loading
//               ? Positioned(
//                   left: 0,
//                   right: 0,
//                   top: 0,
//                   bottom: 0,
//                   child: Material(
//                       color: Colors.transparent,
//                       child: Container(
//                           color: Colors.black.withOpacity(0.9),
//                           child: Center(
//                             child: Column(
//                               mainAxisAlignment: MainAxisAlignment.center,
//                               children: <Widget>[
//                                 CircularPercentIndicator(
//                                   radius: 150.0,
//                                   lineWidth: 7.0,
//                                   animation: true,
//                                   restartAnimation: true,
//                                   animationDuration: 1500,
//                                   percent: 1.0,
//                                   center: Text(
//                                     'Loading...',
//                                     style: FigureFont.gar_15
//                                         .copyWith(color: Colors.white),
//                                   ),
//                                   circularStrokeCap: CircularStrokeCap.round,
//                                   linearGradient: FigureColors.loadingGradient,
//                                 ),
//                                 text != null && text.isNotEmpty
//                                     ? SizedBox(
//                                         height: 30.0,
//                                       )
//                                     : Container(),
//                                 text != null && text.isNotEmpty
//                                     ? Wrap(
//                                         children: <Widget>[
//                                           Padding(
//                                               padding: EdgeInsets.only(
//                                                   left: 40, right: 40),
//                                               child: Text(text,
//                                                   textAlign: TextAlign.center,
//                                                   style: FigureFont.pb_18
//                                                       .copyWith(
//                                                           color: Colors.white)))
//                                         ],
//                                       )
//                                     : Container()
//                               ],
//                             ),
//                           ))))
//               : Container()
//         ],
//       ),
//     );
//   }
// }

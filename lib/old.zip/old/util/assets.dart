class AssetPaths {
  static const images = Images();
}

class Images {
  const Images();

  final String visaLogo = 'assets/images/visa.svg';
  final String figurePayLogo = 'assets/images/figure_pay_logo.png';
}
